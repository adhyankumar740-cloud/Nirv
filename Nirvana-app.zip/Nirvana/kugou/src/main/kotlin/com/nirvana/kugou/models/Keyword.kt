package com.nirvana.kugou.models

data class Keyword(val title: String, val artist: String, val album: String? = null)
