package com.nirvana.music.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.nirvana.music.R

val bbh_bartle = FontFamily(
    Font(R.font.bbh_bartle_regular, FontWeight.Normal)
)
